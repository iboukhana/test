$(function () {
	    		$('.datepicker').datepicker({
	    			
				format:'yyyy/mm/dd',
				
				language: 'fr',
				
				daysOfWeekDisabled: [0, 6]
	        		});
				$('.clockpicker').clockpicker({donetext:'Valider'});
				$('.datepickere').datepicker({
	    			
					format:'yyyy/mm/dd',
					
					language: 'fr',
					
				
						});

				
	  		});